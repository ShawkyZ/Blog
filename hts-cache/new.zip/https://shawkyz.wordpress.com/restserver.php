<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>الصفحة غير موجودة. | مدونة شوقي</title>
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="https://shawkyz.wordpress.com/xmlrpc.php">

<link rel="alternate" type="application/rss+xml" title="مدونة شوقي &raquo; الخلاصة" href="https://shawkyz.wordpress.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="مدونة شوقي &raquo; خلاصة التعليقات" href="https://shawkyz.wordpress.com/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
function addLoadEvent(func){var oldonload=window.onload;if(typeof window.onload!='function'){window.onload=func;}else{window.onload=function(){oldonload();func();}}}
/* ]]> */
</script>
<link rel='stylesheet' id='all-css-0' href='https://s0.wp.com/_static/??-eJyFjt0OgjAMRl/IueBf4oXxWWCUMWxZQzuJb+/AGDUSvWnSk+/0qx3ZuNgr9GopGcbkQy9WKCDceIgdOLWD4icxmaydyMou6xguILPWgXLpLmYmi1qF0b/E6D3UMalpImIc5xtjqD387XRxgMyJS50SBHUoAYFy7JdGfHhaU9e0tvnh5V/fvJGzZaqKBxAxeVJIZLTNhfLlPbDlVNkmOA1XsKI3hCl4plOx2203m+JY7Ls7h96WJA==' type='text/css' media='all' />
<link rel='stylesheet' id='fictive-open-sans-css'  href='https://fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400italic%2C700italic%2C400%2C300%2C700&#038;ver=4.3.1-alpha-336649' type='text/css' media='all' />
<link rel='stylesheet' id='fictive-bitter-css'  href='https://fonts.googleapis.com/css?family=Bitter%3A400%2C700%2C400italic&#038;subset=latin%2Clatin-ext&#038;ver=4.3.1-alpha-336649' type='text/css' media='all' />
<link rel='stylesheet' id='all-css-4' href='https://s0.wp.com/_static/??-eJx9juEKgzAMhF9oXZC5MX+MPYuW2EXapLRxsrdfcYjKwH/fJbncwRSNFVZkhTCa6EdHnMEhY6Ky2GFSv5GmyLPN+QSbH/rCgBni2EFPVumNQGwh68ejmaKV8GfZxGKQgeaYmdYEAhb9lVjg6I9DMV5sqyS8E6b3LaUja8LOiyvooFzNXdbRUugZHlVdX27V9d40wxc35Hk9' type='text/css' media='all' />
<link rel='stylesheet' id='print-css-5' href='https://s1.wp.com/wp-content/mu-plugins/global-print/rtl/global-print-rtl.css?m=1444132114g' type='text/css' media='print' />
<link rel='stylesheet' id='all-css-6' href='https://s1.wp.com/_static/??/wp-content/themes/h4/rtl/global-rtl.css,/wp-content/themes/h4/global-rtl.css?m=1420737423j' type='text/css' media='all' />
<script type='text/javascript'>
/* <![CDATA[ */
var LoggedOutFollow = {"invalid_email":"\u0627\u0634\u062a\u0631\u0627\u0643\u0643 \u063a\u064a\u0631 \u0646\u0627\u062c\u062d\u060c \u064a\u064f\u0631\u062c\u0649 \u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629 \u0645\u0631\u0629 \u0623\u062e\u0631\u0649 \u0628\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0639\u0646\u0648\u0627\u0646 \u0628\u0631\u064a\u062f \u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0635\u0627\u0644\u062d"};
/* ]]> */
</script>
<script type='text/javascript' src='https://s0.wp.com/_static/??-eJyFzs0KwjAMAOAXsiub8+BBfJb9ZCW1bWqTrujTW0EP4lAIJCRfQnSJCsPk8gysbY1rhnR7pcbyTv8CyqNJg0DjMbzxREEgyNN6GtGBygxpMLVXDy204SKxeGCuaGP6+RKGFaH8ZRYkDtNFJWC8f10dHRkVXTYYWNfawExZ1ELOUdEFZwNSd87+1Pb9vuvaY3uwD0gZb60='></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://shawkyz.wordpress.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://s1.wp.com/wp-includes/wlwmanifest.xml" /> 
<link rel="stylesheet" href="https://s0.wp.com/wp-content/themes/pub/fictive/rtl.css?m=1438332384" type="text/css" media="screen" /><meta name="generator" content="WordPress.com" />
<link rel="shortcut icon" type="image/x-icon" href="https://secure.gravatar.com/blavatar/f05a375cdc2e5ec836a4fa3d3d14570b?s=16" sizes="16x16" />
<link rel="icon" type="image/x-icon" href="https://secure.gravatar.com/blavatar/f05a375cdc2e5ec836a4fa3d3d14570b?s=16" sizes="16x16" />
<link rel="apple-touch-icon-precomposed" href="https://secure.gravatar.com/blavatar/584ddeb61278e27b5551cae9dbd79cd3?s=114" />
<link rel='openid.server' href='https://shawkyz.wordpress.com/?openidserver=1' />
<link rel='openid.delegate' href='https://shawkyz.wordpress.com/' />
<link rel="search" type="application/opensearchdescription+xml" href="https://shawkyz.wordpress.com/osd.xml" title="مدونة شوقي" />
<link rel="search" type="application/opensearchdescription+xml" href="https://wordpress.com/opensearch.xml" title="WordPress.com" />
	<style type="text/css">
	body {font-family: Tahoma, Arial, sans-serif;}
	</style>
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<style type="text/css">
			.recentcomments a {
				display: inline !important;
				padding: 0 !important;
				margin: 0 !important;
			}

			table.recentcommentsavatartop img.avatar, table.recentcommentsavatarend img.avatar {
				border: 0px;
				margin: 0;
			}

			table.recentcommentsavatartop a, table.recentcommentsavatarend a {
				border: 0px !important;
				background-color: transparent !important;
			}

			td.recentcommentsavatarend, td.recentcommentsavatartop {
				padding: 0px 0px 1px 0px;
				margin: 0px;
			}

			td.recentcommentstextend {
				border: none !important;
				padding: 0px 0px 2px 10px;
			}

			.rtl td.recentcommentstextend {
				padding: 0px 10px 2px 0px;
			}

			td.recentcommentstexttop {
				border: none;
				padding: 0px 0px 0px 10px;
			}

			.rtl td.recentcommentstexttop {
				padding: 0px 10px 0px 0px;
			}
		</style>
		<meta name="application-name" content="مدونة شوقي" /><meta name="msapplication-window" content="width=device-width;height=device-height" /><meta name="msapplication-tooltip" content="مدونة خاصة بأخبار التنقية و البرمجيات" /><meta name="msapplication-task" content="name=اشترك;action-uri=https://shawkyz.wordpress.com/feed/;icon-uri=https://secure.gravatar.com/blavatar/f05a375cdc2e5ec836a4fa3d3d14570b?s=16" /><meta name="msapplication-task" content="name=سجّل اشتراكك في مدوّنة مجانية;action-uri=http://wordpress.com/signup/;icon-uri=https://s2.wp.com/i/favicon.ico" /><meta name="msapplication-task" content="name=WordPress.com Support;action-uri=http://support.wordpress.com/;icon-uri=https://s2.wp.com/i/favicon.ico" /><meta name="msapplication-task" content="name=منتديات وورد بريس;action-uri=http://forums.wordpress.com/;icon-uri=https://s2.wp.com/i/favicon.ico" /><meta name="title" content="مدونة شوقي on WordPress.com" />
<meta name="description" content="مدونة خاصة بأخبار التنقية و البرمجيات (by Abdelrhman Shawky)" />
<style type="text/css" id="syntaxhighlighteranchor"></style>
</head>

<body class="rtl error404 mp6 customizer-styles-applied has-header-image highlander-enabled highlander-light">
<div id="page" class="hfeed site">

	<header id="masthead" class="site-header" role="banner">
				<a href="https://shawkyz.wordpress.com/" rel="home">
			<img src="https://s0.wp.com/wp-content/themes/pub/fictive/images/header.jpg" width="1112" height="1000" alt="" class="header-image">
		</a>
				<div class="site-branding">
							<div class="header-avatar">
					<a href="https://shawkyz.wordpress.com/" rel="home">
						<img src="https://secure.gravatar.com/avatar/4efbe968ac6a1212dca775dae4e4ce04/?s=140&#038;d=identicon" width="70" height="70" alt="">
					</a>
				</div>
						<h1 class="site-title"><a href="https://shawkyz.wordpress.com/" rel="home">مدونة شوقي</a></h1>
			<h2 class="site-description">مدونة خاصة بأخبار التنقية و البرمجيات</h2>
					</div>

		<div class="menu-toggles clear">
										<h1 id="widgets-toggle" class="menu-toggle"><span class="screen-reader-text">المربعات الجانبية</span></h1>
						<h1 id="search-toggle" class="menu-toggle"><span class="screen-reader-text">بحث </span></h1>
		</div>

		<nav id="site-navigation" class="main-navigation" role="navigation">
			<a class="skip-link screen-reader-text" href="#content">Skip to content</a>
					</nav><!-- #site-navigation -->

			<div id="secondary" class="widget-area" role="complementary">
		<aside id="facebook-likebox-3" class="widget widget_facebook_likebox"><h1 class="widget-title"><a href="https://www.facebook.com/ShawkyBlog">مدونة شوقي</a></h1>		<div id="fb-root"></div>
		<div class="fb-page" data-href="https://www.facebook.com/ShawkyBlog" data-width="400"  data-height="432" data-hide-cover="false" data-show-facepile="true" data-show-posts="false">
		<div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/ShawkyBlog"><a href="https://www.facebook.com/ShawkyBlog">مدونة شوقي</a></blockquote></div>
		</div>
		<script>(function(d, s, id) { var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js = d.createElement(s); js.id = id; js.src = '//connect.facebook.net/ar_AR/sdk.js#xfbml=1&appId=249643311490&version=v2.3'; fjs.parentNode.insertBefore(js, fjs); }(document, 'script', 'facebook-jssdk'));</script>
		</aside><aside id="search-2" class="widget widget_search"><h1 class="widget-title">بحث</h1><form role="search" method="get" class="search-form" action="https://shawkyz.wordpress.com/">
				<label>
					<span class="screen-reader-text">البحث عن:</span>
					<input type="search" class="search-field" placeholder="بحث &hellip;" value="" name="s" title="البحث عن:" />
				</label>
				<input type="submit" class="search-submit" value="بحث " />
			</form></aside>		<aside id="recent-posts-2" class="widget widget_recent_entries">		<h1 class="widget-title">اخر التدوينات</h1>		<ul>
					<li>
				<a href="https://shawkyz.wordpress.com/2014/02/23/%d8%ad%d9%81%d8%b8-%d9%88-%d8%a7%d8%b3%d8%aa%d8%b9%d8%a7%d8%af%d8%a9-backup-%d9%81-mssql-database-%d8%a8%d8%a7%d9%84-c/">حفظ و استعادة Backup ف MSSQL Database بال&nbsp;#C</a>
						</li>
					<li>
				<a href="https://shawkyz.wordpress.com/2014/02/12/%d8%a7%d9%8a%d9%87-%d9%84%d8%a7%d8%b2%d9%85%d8%a9-%d8%a7%d9%84%d9%85%d8%af%d9%88%d9%86%d8%a9-%d8%9f/">ايه لازمة المدونة&nbsp;؟</a>
						</li>
				</ul>
		</aside><aside id="recent-comments-2" class="widget widget_recent_comments"><h1 class="widget-title">اخر التعليقات</h1>				<table class="recentcommentsavatar" cellspacing="0" cellpadding="0" border="0">
					<tr><td title="abdelrhmanshawkyb" class="recentcommentsavatartop" style="height:48px; width:48px;"><a href="https://shawkyz.wordpress.com" rel="nofollow"><img alt='' src='https://1.gravatar.com/avatar/4efbe968ac6a1212dca775dae4e4ce04?s=48&#038;d=identicon&#038;r=G' class='avatar avatar-48' height='48' width='48' /></a></td><td class="recentcommentstexttop" style=""><a href="https://shawkyz.wordpress.com" rel="nofollow">abdelrhmanshawkyb</a> on <a href="https://shawkyz.wordpress.com/2014/02/23/%d8%ad%d9%81%d8%b8-%d9%88-%d8%a7%d8%b3%d8%aa%d8%b9%d8%a7%d8%af%d8%a9-backup-%d9%81-mssql-database-%d8%a8%d8%a7%d9%84-c/comment-page-1/#comment-3">حفظ و استعادة Backup ف MSSQL D&hellip;</a></td></tr><tr><td title="Hossam" class="recentcommentsavatarend" style="height:48px; width:48px;"><img alt='' src='https://0.gravatar.com/avatar/c6d1b3df2991de49bbdf41e26f700736?s=48&#038;d=identicon&#038;r=G' class='avatar avatar-48' height='48' width='48' /></td><td class="recentcommentstextend" style="">Hossam on <a href="https://shawkyz.wordpress.com/2014/02/23/%d8%ad%d9%81%d8%b8-%d9%88-%d8%a7%d8%b3%d8%aa%d8%b9%d8%a7%d8%af%d8%a9-backup-%d9%81-mssql-database-%d8%a8%d8%a7%d9%84-c/comment-page-1/#comment-2">حفظ و استعادة Backup ف MSSQL D&hellip;</a></td></tr>				</table>
				</aside>	</div><!-- #secondary -->

		<div id="site-search" class="header-search">
			<form role="search" method="get" class="search-form" action="https://shawkyz.wordpress.com/">
				<label>
					<span class="screen-reader-text">البحث عن:</span>
					<input type="search" class="search-field" placeholder="بحث &hellip;" value="" name="s" title="البحث عن:" />
				</label>
				<input type="submit" class="search-submit" value="بحث " />
			</form>		</div>
	</header><!-- #masthead -->

	<div id="content" class="site-content">

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<section class="error-404 not-found hentry">
				<header class="page-header">
					<h1 class="entry-title">Oops! That page can&rsquo;t be found.</h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>

					<form role="search" method="get" class="search-form" action="https://shawkyz.wordpress.com/">
				<label>
					<span class="screen-reader-text">البحث عن:</span>
					<input type="search" class="search-field" placeholder="بحث &hellip;" value="" name="s" title="البحث عن:" />
				</label>
				<input type="submit" class="search-submit" value="بحث " />
			</form>
				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->


	</div><!-- #content -->

	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="site-info">
			<a href="https://ar.wordpress.com/?ref=footer_website">أنشئ موقعاً أو مدونة مجانية على ووردبريس دوت كوم.</a>.
			<span class="sep"> | </span>
			<a href="https://wordpress.com/themes/fictive/" title="Learn more about this theme">قالب Fictive</a>.		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<!-- wpcom_wp_footer -->
<script type='text/javascript' src='//0.gravatar.com/js/gprofiles.js?ver=201541y'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var WPGroHo = {"my_hash":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://s2.wp.com/wp-content/mu-plugins/gravatar-hovercards/wpgroho.js?m=1380573781g'></script>

	<script>
		//initialize and attach hovercards to all gravatars
		jQuery( document ).ready( function( $ ) {

			if (typeof Gravatar === "undefined"){
				return;
			}

			if ( typeof Gravatar.init !== "function" ) {
				return;
			}			

			Gravatar.profile_cb = function( hash, id ) {
				WPGroHo.syncProfileData( hash, id );
			};
			Gravatar.my_hash = WPGroHo.my_hash;
			Gravatar.init( 'body', '#wp-admin-bar-my-account' );
		});
	</script>

		<div style="display:none">
	<div class="grofile-hash-map-4efbe968ac6a1212dca775dae4e4ce04">
	</div>
	<div class="grofile-hash-map-c6d1b3df2991de49bbdf41e26f700736">
	</div>
	</div>

	<div id="bit" class="loggedout-follow-normal">
		<a class="bsub" href="javascript:void(0)"><span id='bsub-text'>تابع</span></a>
		<div id="bitsubscribe">

					<h3><label for="loggedout-follow-field">تابع "مدونة شوقي"</label></h3>

			<form action="https://subscribe.wordpress.com" method="post" accept-charset="utf-8" id="loggedout-follow">
			<p>احصل على كل تدوينة جديدة تم توصيلها إلى علبة الوارد لديك.</p>

			<p id="loggedout-follow-error" style="display: none;"></p>

						<p class="bit-follow-count">انضم 374 متابعون آخرين</p>
			<p><input type="email" name="email" placeholder="أكتب بريدك الإلكتروني" id="loggedout-follow-field"/></p>

			<input type="hidden" name="action" value="subscribe"/>
			<input type="hidden" name="blog_id" value="64194303"/>
			<input type="hidden" name="source" value="https://shawkyz.wordpress.com/restserver.php"/>
			<input type="hidden" name="sub-type" value="loggedout-follow"/>

			<input type="hidden" id="_wpnonce" name="_wpnonce" value="c3dcfe7fc9" /><input type="hidden" name="_wp_http_referer" value="/restserver.php" />
			<p id='bsub-subscribe-button'><input type="submit" value="سجل دخولي" /></p>
			</form>
					<div id='bsub-credit'><a href="https://ar.wordpress.com/?ref=lof">إنشاء موقع ويب باستخدام WordPress.com</a></div>
		</div><!-- #bitsubscribe -->
	</div><!-- #bit -->
<link rel='stylesheet' id='all-css-0' href='https://s2.wp.com/wp-content/mu-plugins/widgets/facebook-likebox/style.css?m=1436472654g' type='text/css' media='all' />
<script type='text/javascript'>
/* <![CDATA[ */
var JetpackEmojiSettings = {"base_url":"https:\/\/s0.wp.com\/wp-content\/mu-plugins\/emoji\/twemoji\/"};
/* ]]> */
</script>
<script type='text/javascript' src='https://s2.wp.com/_static/??-eJyNzcEKAjEMBNAfMkaXBd2D+C1aU026bQNJd/18ERQUD+5pBubB4KwQanEqjmJ4oYkD6X0ttsKPyW+UyVDbGSMH54me+lWXYUusMHJJEGtoBpF/XnIDHduViyHlKow+f+VfL+R6CgmW6bc65sO274Zu2G/6nTwANXFlPA=='></script>
<script type="text/javascript">
// <![CDATA[
(function() {
try{
  if ( window.external &&'msIsSiteMode' in window.external) {
    if (window.external.msIsSiteMode()) {
      var jl = document.createElement('script');
      jl.type='text/javascript';
      jl.async=true;
      jl.src='/wp-content/plugins/ie-sitemode/custom-jumplist.php';
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(jl, s);
    }
  }
}catch(e){}
})();
// ]]>
</script>	<script type="text/javascript">
	var skimlinks_pub_id = "725X584219"
	var skimlinks_sitename = "shawkyz.wordpress.com";
	</script>
	<script type="text/javascript" src="https://s.skimresources.com/js/725X1342.skimlinks.js"></script><script>
if ( 'object' === typeof wpcom_mobile_user_agent_info ) {

	wpcom_mobile_user_agent_info.init();
	var mobileStatsQueryString = "";
	
	if( false !== wpcom_mobile_user_agent_info.matchedPlatformName )
		mobileStatsQueryString += "&x_" + 'mobile_platforms' + '=' + wpcom_mobile_user_agent_info.matchedPlatformName;
	
	if( false !== wpcom_mobile_user_agent_info.matchedUserAgentName )
		mobileStatsQueryString += "&x_" + 'mobile_devices' + '=' + wpcom_mobile_user_agent_info.matchedUserAgentName;
	
	if( wpcom_mobile_user_agent_info.isIPad() )
		mobileStatsQueryString += "&x_" + 'ipad_views' + '=' + 'views';

	if( "" != mobileStatsQueryString ) {
		new Image().src = document.location.protocol + '//pixel.wp.com/g.gif?v=wpcom-no-pv' + mobileStatsQueryString + '&baba=' + Math.random();
	}
	
}
</script>
</body>
</html>
